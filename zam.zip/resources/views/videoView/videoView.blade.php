@extends('layouts.layout_main')

@section('content')
  <div class="col-md-12 text-center">
    <h3><strong>Дүрс бичлэг</strong></h3>
  </div>

@endsection

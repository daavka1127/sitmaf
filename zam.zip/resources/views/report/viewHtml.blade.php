@extends('layouts.layout_main')

@section('content')
<?php include 'test.html'; ?>
@endsection

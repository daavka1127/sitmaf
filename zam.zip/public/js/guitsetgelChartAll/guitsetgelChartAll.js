$(document).ready(function(){
  $("#cmbHeseg").change(function(){
    $("#cmbCompany").val("0");
    
    $("#chartContent").html('dadaa');
  });
});

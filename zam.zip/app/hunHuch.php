<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class hunHuch extends Model
{
    protected $table = 'tb_hunhuch';
    public $primaryKey = 'id';
    public $timestamps = false;
}

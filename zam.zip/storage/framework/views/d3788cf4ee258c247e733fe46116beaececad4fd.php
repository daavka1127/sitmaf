
<div class="modal fade" id="newCompany">
  <div class="modal-dialog" style="width:80%;">
    <div class="modal-content">

      <div class="modal-header">
        <span class="red-required">* - той талбарыг заавал бөглөнө үү!!!</span>
        <button type="button" class="close" data-dismiss="modal">X</button>
      </div>

      <div class="modal-body">
        <h2 style="text-align:center;"><strong>Бүртгэгдсэн аж ахуйн нэгж бүртгэл</strong></h2>
        <form id="frmNewCompany" action="<?php echo e(action('companyController@store')); ?>" method="post" data-parsley-validate class="form-horizontal form-label-left">
          <?php echo csrf_field(); ?>
          <input type="hidden" id="companyID" name="companyID" value="0" />
          <div class="form-group col-md-3 text-left">
            <label>Аж ахуйн нэгжийн нэр <span class="red-required">*</span> </label>
            <input type="text" id="txtCompanyName" name="companyName" class="form-control" />
          </div>
          <div class="form-group col-md-3 text-left">
            <label>Хэсэг <span class="red-required">*</span> </label>
            <?php
              $getTbHeseg = \App\Http\Controllers\companyController::getHesegID();
            ?>
            <select class="form-control" id="cmbHeseg" name="heseg_id">
              <?php $__currentLoopData = $getTbHeseg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbHeseg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($tbHeseg->id); ?>"><?php echo e($tbHeseg->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
          </div>
          <div class="form-group col-md-3 text-left">
            <label>Ажлын хэсэг <span class="red-required">*</span> </label>
            <input type="text" id="txtAjliinHeseg" name="ajliinHeseg" class="form-control" required />
          </div>
          <div class="form-group col-md-3 text-left">
            <label>Ажил эхэлсэн огноо <span class="red-required">*</span> </label>
            <input type="date" id="txtGereeOgnoo" name="gereeOgnoo" class="form-control" required />
          </div>
          <div class="form-group col-md-3 text-left">
            <label>Хүн хүч </label>
            <input type="number" min="0" step="1" id="txtHunHuch" name="hunHuch" class="form-control" required />
          </div>
          <div class="form-group col-md-3 text-left">
            <label>Ажлын машин техник </label>
            <input type="number" min="0" step="1" id="txtMashinTehnik" name="mashinTehnik" class="form-control" required />
          </div>
          </form>
          <div class="clearfix"></div>
          <h4 style="text-align:center;"><strong>Төсөвлөсөн ажил</strong></h4>
          <?php
            $worktypes = \App\Http\Controllers\WorktypeController::getCompactWorkType();
          ?>
          <?php $__currentLoopData = $worktypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worktype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12">
                <label class="checkbox-inline"><input type="checkbox" workTypeId="<?php echo e($worktype->id); ?>" id="checkBoxes<?php echo e($worktype->id); ?>">  <?php echo e($worktype->name); ?></label>
            </div>

              <div class="col-md-12 vision"  style="display:none; border: 1px solid grey; margin-top: 5px; border-radius: 5px; border-color: #d1cfcf;" id="worktypeid<?php echo e($worktype->id); ?>">
                <?php
                  $works = \App\Http\Controllers\WorkController::getCompactWorks($worktype->id);
                  $i=0;
                ?>

                  <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group col-md-2 text-left" style="padding-top: 5px;">
                      <label style="font-size: 11px;"><?php echo e($work->name); ?> /<?php echo e($work->hemjih_negj); ?>/</label>
                      <input type="number" min="0" step="1" workID="<?php echo e($work->id); ?>" class="txtclass<?php echo e($worktype->id); ?> form-control input-sm" />
                    </div>
                    <?php $i++; ?>
                    <?php if($i%6 == 0): ?>
                        <div class="clearfix"></div>
                    <?php endif; ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php if(count($works) != 0): ?>
                    <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
                      <button type="button" btnworkid="<?php echo e($worktype->id); ?>" class="btnWorkTypeID btn btn-success">Хадгалах</button>
                    </div>
                  <?php endif; ?>
              </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
      <div class="clearfix"></div>
      <div class = "modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Хаах</button>
      </div>

    </div>
  </div>
</div>

<?php /**PATH C:\xampp\htdocs\zam\resources\views/company/companyNew.blade.php ENDPATH**/ ?>
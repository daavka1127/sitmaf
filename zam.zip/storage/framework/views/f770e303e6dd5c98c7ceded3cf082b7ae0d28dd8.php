<?php $__env->startSection('content'); ?>

<div class="container">


<h3><strong>Зураг оруулах</strong></h3>
<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>



<?php echo Form::open(array('route' => 'resizeImagePost','enctype' => 'multipart/form-data')); ?>

    <div class="row">
        <div class="col-md-4">
            <br/>
            <?php echo Form::text('title', null,array('class' => 'form-control','placeholder'=>'Add Title', 'multiple')); ?>


        </div>
        <div class="col-md-12">
            <br/>
            <?php echo Form::file('image', array('class' => 'image')); ?>

        </div>
        <div class="col-md-12">
            <br/>
            <div class="col-md-4"><p class="red-required">Таны зураг 2MB-аас бага байх шаардлагатайг анхаарна уу!!!</p></div>
            <div class="clearfix"></div>
            <button type="submit" class="btn btn-success">Зураг хадгалах</button>
        </div>
    </div>
<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zam\resources\views/imagesView/imageNew.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

  <div class="clearfix"></div>
  <div class="row">
    <script>
      $(document).ready(function(){
          $("#cmbCompany").change(function(){
            $(".divWorkType").css("display","block");
              window.location.href = "<?php echo e(url('/chart/byDate')); ?>/" + $("#cmbCompany").val() + "/" + $("#cmbWorkType").val();
          });
      });
    </script>
    <script>
      $(document).ready(function(){
          $("#cmbHeseg").change(function(){
            $(".divWorkType").css("display","none");
              window.location.href = "<?php echo e(url('/chart/all')); ?>/" + $("#cmbHeseg").val();
          });
      });
    </script>
    <div class="col-md-4">
      <label>Хэсгээр харах</label>
      <select class="form-control" id="cmbHeseg">
        <option value="0">Сонгоно уу</option>
        <option value="1">Зүүнбаян чиглэл I хэсэг</option>
        <option value="2">Мандах чиглэл II хэсэг</option>
        <option value="3">Цогтцэций чиглэл III чиглэл</option>
        <option value="4">Бүх аж ахуйн нэгжээр</option>
      </select>
    </div>
    <div class="col-md-4">
      <label>Аж ахуйн нэгжээр харах</label>
      <select class="form-control" id="cmbCompany">
        <option value="0">Сонгоно уу</option>
        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($company->id); ?>"><?php echo e($company->companyName); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="divWorkType col-md-4" style="display: none;">
      <label>Хийгдэж буй ажлын төрөл</label>
      <select class="form-control" id="cmbWorkType">
        <option value="0">Сонгоно уу</option>
        <?php
          $workTypes = App\Http\Controllers\WorktypeController::getCompactWorkType();
        ?>
        <?php $__currentLoopData = $workTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($workType->id); ?>"><?php echo e($workType->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  </div>

  <div style="display:none;" id="loading" class="col-md-2 col-md-offset-5">
    <br/>
    <div class="clearfix"></div>
    <img width="100" src="<?php echo e(url('public/images/loading_big.gif')); ?>" />
  </div>
  <div id="chartContent">

  </div>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zam\resources\views/home.blade.php ENDPATH**/ ?>
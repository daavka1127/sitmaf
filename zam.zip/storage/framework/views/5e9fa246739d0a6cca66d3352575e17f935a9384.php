<?php $__env->startSection('content'); ?>
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/jqChart/jqstyles.css')); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/jqChart/jquery.jqChart.css')); ?>" />
	<script src="<?php echo e(url('public/jqChart/jquery.jqChart.min.js')); ?>" type="text/javascript"></script>
  <script lang="javascript" type="text/javascript">
      $(document).ready(function () {
          $('#jqChart').jqChart({
              title: { text: 'Аж ахуйн нэгжийн гүйцэтгэлийн хувь' },
              animation: {
                  duration: 1
              },
              axes: [
                  {
                      type: 'category',
                      location: 'bottom',

                      categories: [
                        <?php $__currentLoopData = $companiesChart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            '<?php echo $company->companyName; ?>',
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ],
                      labels: {
                          font: '12px sans-serif',
                          angle: -90
                      }
                  }
              ],
              series: [
                  {
										title: 'Гүйцэтгэлийн хувь',
                      type: 'column',
                      data: [
                        <?php $__currentLoopData = $companiesChart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                          $dundaj = App\Http\Controllers\GuitsetgelController::getGuitsetgelHuvi($company->id);
                        ?>
                            <?php echo e(round($dundaj, 2)); ?>,
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      ]
                  }
              ]
          });
      });
  </script>
  <div class="clearfix"></div>
  <div class="row">
    <script>
      $(document).ready(function(){
          $("#cmbCompany").change(function(){
            $(".divWorkType").css("display","block");
            $("#cmbWorkType").val("0");
          });

          $("#cmbWorkType").change(function(){
            window.location.href = "<?php echo e(url('/chart/byDate')); ?>/" + $("#cmbCompany").val() + "/" + $("#cmbWorkType").val();
          });
      });
    </script>
    <script>
      $(document).ready(function(){
          $("#cmbHeseg").change(function(){
              $(".divWorkType").css("display","none");
              window.location.href = "<?php echo e(url('/chart/all')); ?>/" + $("#cmbHeseg").val();
          });
      });
    </script>
    <div class="col-md-4">
      <label>Хэсгээр харах</label>
      <select class="form-control" id="cmbHeseg">
        <option value="0">Сонгоно уу</option>
        <?php if($hesegID == 1): ?>
            <option value="1" selected>Зүүнбаян чиглэл I хэсэг</option>
        <?php else: ?>
            <option value="1">Зүүнбаян чиглэл I хэсэг</option>
        <?php endif; ?>
        <?php if($hesegID == 2): ?>
            <option value="2" selected>Мандах чиглэл II хэсэг</option>
        <?php else: ?>
            <option value="2">Мандах чиглэл II хэсэг</option>
        <?php endif; ?>
        <?php if($hesegID == 3): ?>
            <option value="3" selected>Цогтцэций чиглэл III чиглэл</option>
        <?php else: ?>
            <option value="3">Цогтцэций чиглэл III чиглэл</option>
        <?php endif; ?>
        <?php if($hesegID == 4): ?>
            <option value="4" selected>Бүх аж ахуйн нэгжээр</option>
        <?php else: ?>
            <option value="4">Бүх аж ахуйн нэгжээр</option>
        <?php endif; ?>
      </select>
    </div>
    <div class="col-md-4">
      <label>Аж ахуйн нэгжээр харах</label>
      <select class="form-control" id="cmbCompany">
        <option value="0">Сонгоно уу</option>
        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($company->id); ?>"><?php echo e($company->companyName); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="divWorkType col-md-4" style="display:none;">
      <label>Хийгдэж буй ажлын төрөл</label>
      <select class="form-control" id="cmbWorkType">
        <option value="0">Сонгоно уу</option>
        <?php
          $workTypes = App\Http\Controllers\WorktypeController::getCompactWorkType();
        ?>

        <?php $__currentLoopData = $workTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($workType->id); ?>"><?php echo e($workType->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  </div>
  <br>
  <div class="clearfix"></div>
  <script>
  window.onload = function () {

  //Better to construct options first and then pass it as a parameter
  var options = {
  	animationEnabled: true,
  	theme: "light2", //"light1", "dark1", "dark2"
  	title:{
  		text: "Нийт гүйцэтгэлийн график үзүүлэлт"
  	},
  	axisY:{
  		interval: 10,
  		suffix: "%"
  	},
  	toolTip:{
  		shared: true
  	},
  	data:[{
  		type: "stackedBar100",
  		toolTipContent: "{label}<br><b>{name}:</b> {y} (#percent%)",
  		showInLegend: true,
  		name: "Гүйцэтгэлт",
      <?php
        $huvi = App\Http\Controllers\GuitsetgelController::generalChart(4);
        $huvi1 = App\Http\Controllers\GuitsetgelController::generalChart(1);
        $huvi2 = App\Http\Controllers\GuitsetgelController::generalChart(2);
        $huvi3 = App\Http\Controllers\GuitsetgelController::generalChart(3);
      ?>
  		dataPoints: [
  			{ y: <?php echo e($huvi); ?>, label: "Нийт" },
        { y: <?php echo e($huvi1); ?>, label: "Зүүнбаян чиглэл I хэсэг" },
        { y: <?php echo e($huvi2); ?>, label: "Мандах чиглэл II хэсэг" },
        { y: <?php echo e($huvi3); ?>, label: "Цогтцэций чиглэл III чиглэл" },
  		]
  	},
  	{
  		type: "stackedBar100",
  		toolTipContent: "<b>{name}:</b> {y} (#percent%)",
  		showInLegend: true,
  		name: "Үлдсэн",
  		dataPoints: [
        { y: <?php echo e(100 - $huvi); ?>, label: "Нийт" },
        { y: <?php echo e(100 - $huvi1); ?>, label: "Зүүнбаян чиглэл I хэсэг" },
        { y: <?php echo e(100 - $huvi2); ?>, label: "Мандах чиглэл II хэсэг" },
        { y: <?php echo e(100 - $huvi3); ?>, label: "Цогтцэций чиглэл III чиглэл" },
  		]
  	}]
  };

  $("#chartContainer").CanvasJSChart(options);
  }
  </script>
  <div class="clearfix"></div>
  <br>
  <div>
      <div id="jqChart" style="height: 650px;" class="col-md-12"></div>
  </div>
<div class="clearfix"></div>
<br>
  <div id="chartContainer" style="height: 400px; max-width: 4050px; margin: 0px auto;"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zam\resources\views/chart/guitsetgelAllChartJqChart.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<link href="<?php echo e(url('public/dadaaFancy/jquery.fancybox.min.css')); ?>" rel="stylesheet" />
<script src="<?php echo e(url('public/dadaaFancy/jquery.fancybox.min.js')); ?>"></script>
<div class="col-md-12 text-center">
  <h3><strong>Зургийн цомог</strong></h3>
</div>
<div class="container">

<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <a href="<?php echo e(url('/public/images')); ?>/<?php echo e($image->url); ?>" data-fancybox="images" data-caption="<?php echo e($image->title); ?>">
  	<img src="<?php echo e(url('/public/thumbnail')); ?>/<?php echo e($image->url); ?>" alt="" />
  </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
$('[data-fancybox="images"]').fancybox({
  afterLoad : function(instance, current) {
    var pixelRatio = window.devicePixelRatio || 1;

    if ( pixelRatio > 1.5 ) {
      current.width  = current.width  / pixelRatio;
      current.height = current.height / pixelRatio;
    }
  }
});
</script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zam\resources\views/imagesView/resizeImage.blade.php ENDPATH**/ ?>
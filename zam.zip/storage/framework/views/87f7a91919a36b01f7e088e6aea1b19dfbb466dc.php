<script>
window.onload = function () {

    //Better to construct options first and then pass it as a parameter
    var options1 = {
    	animationEnabled: true,
    	theme: "light1", //"light1", "dark1", "dark2"
    	title:{
    		text: ""
    	},
    	axisY:{
    		interval: 10,
    		suffix: "%"
    	},
    	toolTip:{
    		shared: true
    	},
    	data:[{
    		type: "stackedColumn100",
    		toolTipContent: "{label}<br><b>{name}:</b> {y} (#percent%)",
    		showInLegend: true,
    		name: "Гүйцэтгэл",
    		dataPoints: [
            <?php if($guitsetgel->hursHuulalt != null || $guitsetgel->hursHuulalt != 0): ?>
            { y: <?php echo e(100*$guitsetgel->gHursHuulalt/$guitsetgel->hursHuulalt); ?>, label: "Хөрс хуулалт" },
            <?php endif; ?>
            <?php if($guitsetgel->dalan != null || $guitsetgel->dalan != 0): ?>
            { y: <?php echo e(100*$guitsetgel->gDalan/$guitsetgel->dalan); ?>, label: "Далан" },
            <?php endif; ?>
            <?php if($guitsetgel->uhmal != null || $guitsetgel->uhmal != 0): ?>
            { y: <?php echo e(100*$guitsetgel->gUhmal/$guitsetgel->uhmal); ?>, label: "Ухмал" },
            <?php endif; ?>
            <?php if($guitsetgel->suuriinUy != null || $guitsetgel->suuriinUy != 0): ?>
            { y: <?php echo e(100*$guitsetgel->gSuuriinUy/$guitsetgel->suuriinUy); ?>, label: "Суурийн үе" },
            <?php endif; ?>
            <?php if($guitsetgel->shuuduu != null || $guitsetgel->shuuduu != 0): ?>
            { y: <?php echo e(100*$guitsetgel->gShuuduu/$guitsetgel->shuuduu); ?>, label: "Шуудуу" },
            <?php endif; ?>
            <?php if($guitsetgel->uhmaliinHamgaalalt != null || $guitsetgel->uhmaliinHamgaalalt != 0): ?>
            { y: <?php echo e(100*$guitsetgel->gUhmaliinHamgaalalt/$guitsetgel->uhmaliinHamgaalalt); ?>, label: "Ухмалын хамгаалалт" },
            <?php endif; ?>
            <?php if($guitsetgel->uuliinShuuduu != null || $guitsetgel->uuliinShuuduu != 0): ?>
            { y: <?php echo e(100*$guitsetgel->gUuliinShuuduu/$guitsetgel->uuliinShuuduu); ?>, label: "Уулын шуудуу" }
            <?php endif; ?>

    		]
    	},
    	{
    		type: "stackedColumn100",
    		toolTipContent: "<b>{name}:</b> {y} (#percent%)",
    		showInLegend: true,
    		name: "Үлдсэн ажил",
    		dataPoints: [

          <?php if($guitsetgel->hursHuulalt != null || $guitsetgel->hursHuulalt != 0): ?>
          { y: <?php echo e(100-100*$guitsetgel->gHursHuulalt/$guitsetgel->hursHuulalt); ?>, label: "Хөрс хуулалт" },
          <?php endif; ?>
          <?php if($guitsetgel->dalan != null || $guitsetgel->dalan != 0): ?>
          { y: <?php echo e(100-100*$guitsetgel->gDalan/$guitsetgel->dalan); ?>, label: "Далан" },
          <?php endif; ?>
          <?php if($guitsetgel->uhmal != null || $guitsetgel->uhmal != 0): ?>
          { y: <?php echo e(100-100*$guitsetgel->gUhmal/$guitsetgel->uhmal); ?>, label: "Ухмал" },
          <?php endif; ?>
          <?php if($guitsetgel->suuriinUy != null || $guitsetgel->suuriinUy != 0): ?>
          { y: <?php echo e(100-100*$guitsetgel->gSuuriinUy/$guitsetgel->suuriinUy); ?>, label: "Суурийн үе" },
          <?php endif; ?>
          <?php if($guitsetgel->shuuduu != null || $guitsetgel->shuuduu != 0): ?>
          { y: <?php echo e(100-100*$guitsetgel->gShuuduu/$guitsetgel->shuuduu); ?>, label: "Шуудуу" },
          <?php endif; ?>
          <?php if($guitsetgel->uhmaliinHamgaalalt != null || $guitsetgel->uhmaliinHamgaalalt != 0): ?>
          { y: <?php echo e(100-100*$guitsetgel->gUhmaliinHamgaalalt/$guitsetgel->uhmaliinHamgaalalt); ?>, label: "Ухмалын хамгаалалт" },
          <?php endif; ?>
          <?php if($guitsetgel->uuliinShuuduu != null || $guitsetgel->uuliinShuuduu != 0): ?>
          { y: <?php echo e(100-100*$guitsetgel->gUuliinShuuduu/$guitsetgel->uuliinShuuduu); ?>, label: "Уулын шуудуу" }
          <?php endif; ?>

    		]
    	}]
    };

    $("#chartContainer123").CanvasJSChart(options1);
}
</script>
<?php /**PATH C:\xampp\htdocs\zam\resources\views/chart/chartByTorol.blade.php ENDPATH**/ ?>
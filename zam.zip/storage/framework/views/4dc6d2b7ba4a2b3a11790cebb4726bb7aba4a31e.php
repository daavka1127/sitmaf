<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Тайлан хэвлэх</title>
    <!-- Bootstrap -->
    <link href="<?php echo e(url('public/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- jQuery -->
    <script src="<?php echo e(url('public/vendors/jquery/dist/jquery.min.js')); ?>"></script>
  </head>
  <body>
    <?php echo $__env->yieldContent('content'); ?>
    <!-- Bootstrap -->
    <script src="<?php echo e(url('public/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\zam\resources\views/layouts/layout_print.blade.php ENDPATH**/ ?>
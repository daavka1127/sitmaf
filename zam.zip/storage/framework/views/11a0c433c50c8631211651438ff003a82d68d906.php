<?php $__env->startSection('content'); ?>
<h1>Зураг оруулах</h1>
<div class="clearfix"></div>
<input type="file" id="myFiles" name="images" multiple="multiple" />
<button class="btn btn-sm btn-info upload" id="btnUpload" data-url="<?php echo e(route("resizeImagePost")); ?>" type="submit">Upload</button>
<div id="showImages"></div>
<ul id="image-list"></ul>
<br>
<br>
<br>
<br>

<style>

    #post-image {
        /* object-fit: contain; */
        object-fit: cover;
        border: 5px solid;
    }
</style>
<script type="text/javascript">
</script>

<script src="<?php echo e(url("/public/js/imageUpload/uploadImage.js")); ?>"></script>

<!-- NProgress -->
    <script src="<?php echo e(url("/public/vendors/nprogress/nprogress.js")); ?>"></script>
    <!-- bootstrap-progressbar -->
    <script src="<?php echo e(url("/public/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js")); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zam\resources\views/imagesView/ajaxImageTool.blade.php ENDPATH**/ ?>
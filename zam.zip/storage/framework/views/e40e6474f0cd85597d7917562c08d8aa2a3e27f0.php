<?php $__env->startSection('content'); ?>
  <div class="clearfix"></div>
  <div class="row">
    <script>
      $(document).ready(function(){
          $("#cmbCompany").change(function(){
              window.location.href = "<?php echo e(url('/chart/byDate')); ?>/" + $("#cmbCompany").val();
          });
      });
    </script>
    <script>
      $(document).ready(function(){
          $("#cmbHeseg").change(function(){
              window.location.href = "<?php echo e(url('/chart/all')); ?>/" + $("#cmbHeseg").val();
          });
      });
    </script>
    <div class="col-md-4">
      <label>Хэсгээр харах</label>
      <select class="form-control" id="cmbHeseg">
        <option value="0">Сонгоно уу</option>
        <option value="1">Зүүнбаян чиглэл I хэсэг</option>
        <option value="2">Мандах чиглэл II хэсэг</option>
        <option value="3">Цогтцэций чиглэл III чиглэл</option>
        <option value="4">Бүх аж ахуйн нэгжээр</option>
      </select>
    </div>
    <div class="col-md-4">
      <label>Аж ахуйн нэгжээр харах</label>
      <select class="form-control" id="cmbCompany">
        <option value="0">Сонгоно уу</option>
        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($companyID == $company->id): ?>
            <option value="<?php echo e($company->id); ?>" selected><?php echo e($company->companyName); ?></option>
          <?php else: ?>
            <option value="<?php echo e($company->id); ?>"><?php echo e($company->companyName); ?></option>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  </div>
  <link href="<?php echo e(url('public/jqChart/jqstyles.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(url('public/jqChart/jquery.jqChart.css')); ?>" rel="stylesheet">
  <script src="<?php echo e(url('public/jqChart/jquery.jqChart.min.js')); ?>"></script>
  <div class="clearfix"></div>
  <br>
  <?php echo $__env->make('chart.chartByDate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="clearfix"></div>
<?php echo $__env->make('chart.chartByTorol', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="jqChart" style="height: 370px; max-width: 920px; margin: 0px auto; background-color: #fff"></div>
<div class="clearfix"></div>
<br>
<div style="color: black; font-size: 20px; font-weight: bold" class="col-md-12 col-md-offset-5">Гүйцэтгэл /үзүүлэлтээр/</div>
<div class="clearfix"></div>

<div id="chartContainer123" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zam\resources\views/chart/showCharts.blade.php ENDPATH**/ ?>
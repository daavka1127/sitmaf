<?php $__env->startSection('content'); ?>

  <script src="<?php echo e(url('/public/js/davkaFreeze/jquery-stickytable.js')); ?> "></script>
  <link rel="stylesheet" type="text/css" href=" <?php echo e(url('/public/js/davkaFreeze/jquery-stickytable.css')); ?> " />

  <script src="<?php echo e(url('/public/js/printReport/printReport.js')); ?> "></script>
<?php
  $workTypes = \App\Http\Controllers\WorktypeController::getCompactWorkType();
?>

<style>

@media  print {
  /* body * {
    visibility: hidden;
  } */


   #onlyPrint {
    visibility: visible;
    width: 100%;
  }
  #hideRowBeforPrint{
    display: none;
  }

  #clear{
    display: none;
  }
}
</style>

<div class="row" id="hideRowBeforPrint">
  <?php $__currentLoopData = $workTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-12">
        <label class="checkbox-inline"><input type="checkbox" workTypeId="<?php echo e($workType->id); ?>" id="checkWorkType<?php echo e($workType->id); ?>">  <?php echo e($workType->name); ?></label>
    </div>
    <div class="col-md-12 vision" style="display:none; border: 1px solid grey; margin-top: 5px; border-radius: 5px; border-color: #d1cfcf;" id="worktypeid<?php echo e($workType->id); ?>">
      <?php
        $works = \App\Http\Controllers\WorkController::getCompactWorks($workType->id);
      ?>
      <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label class="checkbox-inline"><input type="checkbox" class="checkWork" workId="<?php echo e($work->id); ?>" id="checkWork<?php echo e($work->id); ?>" checked>  <?php echo e($work->name); ?></label>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div id="onlyPrint">

  <h5 class="text-center"><strong>ТАВАНТОЛГОЙ-ЗҮҮНБАЯН ЧИГЛЭЛИЙН 416.165  КМ ТӨМӨР ЗАМЫН ШУГАМЫН ДООД БҮТЦИЙН ГАЗАР ШОРООНЫ АЖЛЫН МЭДЭЭ</strong></h5>


  <?php
    $hesegs = \App\Http\Controllers\HesegController::getHeseg();
    $j=0;
  ?>

  <?php $__currentLoopData = $hesegs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heseg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
    <?php
      $companies = \App\Http\Controllers\companyController::getCompanyByHeseg($heseg->id);
      $j++;
      if($j == 3){
        $widthNumber = 9;
      }
      else{
        $widthNumber = 12;
      }
    ?>
    <h6 class="text-left"><?php echo e($heseg->name); ?></h6>


    
  <div class="col-md-<?php echo e($widthNumber); ?> text-center">
    <table border="1" class="table<?php echo e($heseg->id); ?>">
      <thead>
        <tr class="text-left">
          <th>Мэдээ агуулга</th>
          <th>Мэдээ агуулга</th>
          <th>Мэдээ агуулга</th>
          <th colspan="<?php echo e($companies->count()); ?>">Ажил гүйцэтгэх Зэвсэгт хүчний анги, туслан гүйцэтгэгч аж ахуйн нэгж байгууллага</th>
        </tr>
        <tr class="text-left">
          <th>Мэдээ агуулга</th>
          <th>Мэдээ агуулга</th>
          <th>Мэдээ агуулга</th>
          <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th class="verticalTD  text-center"><div class="rotate"><?php echo e($company->companyName); ?></div></th>
            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
      </thead>
      <tbody>
        <tr class="text-left">
          <td>Ерөнхий мэдээлэл</td>
          <td colspan="2">Хариуцах ПК-ийн байршил</td>
          <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th class="rotate-45 text-center"><div><span><?php echo e($company->ajliinHeseg); ?></span></div></th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <tr class="text-left">
          <td>Ерөнхий мэдээлэл</td>
          <td colspan="2"> Батлагдсан тоо хэмжээ /м.куб/</td>
          <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $sumPlan = \App\Http\Controllers\planController::getSumPlanCompany($company->id);
            ?>
            <th class="rotate-45"><div><span><?php echo e($sumPlan); ?></span></div></th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <tr class="text-left">
          <td>Ерөнхий мэдээлэл</td>
          <td colspan="2">2019 оны гүйцэтгэл /хувь/</td>
          <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $percent2019 = \App\Http\Controllers\ExecutionContoller::getExecutionPercentByCompany2019($company->id);
            ?>
            <th class="rotate-45"><div><span><?php echo e($percent2019); ?></span></div></th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <tr class="text-left">
          <td>Ерөнхий мэдээлэл</td>
          <td colspan="2">2020 онд гүйцэтгэх тоо хэмжээ /м.куб/</td>
          <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $execution2020 = \App\Http\Controllers\ExecutionContoller::getSumExecutionByCompany2020($company->id);
            ?>
            <th class="rotate-45"><div><span><?php echo e($execution2020); ?></span></div></th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <?php
          $works = \App\Http\Controllers\WorkController::getWorksAll($company->id);
        ?>

        <?php for($i=0; $i<$works->count(); $i++): ?>
          <tr class="<?php echo e($works[$i]->work_type_id); ?> text-left" id="prev<?php echo e($works[$i]->id); ?>">
            <td>Мэдээний хугацаанд гүйцэтгэсэн</td>
            <td><?php echo e($works[$i]->name); ?></td>
            <td class="text-center">Өмнөх тайлангийн бүгд</td>
            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $previousReportExecution = \App\Http\Controllers\ExecutionContoller::previousReportExecutionByComIdWorkID($company->id, $works[$i]->id);
              ?>
              <td class="text-center"><?php echo e($previousReportExecution); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
          <tr class="<?php echo e($works[$i]->work_type_id); ?> text-left" id="report<?php echo e($works[$i]->id); ?>">
            <td>Мэдээний хугацаанд гүйцэтгэсэн</td>
            <td><?php echo e($works[$i]->name); ?></td>
            <td>Тайлант үеийн</td>
            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $lastExec = \App\Http\Controllers\ExecutionContoller::getLastExecByComIdWorkID($company->id, $works[$i]->id);
              ?>
              <td><?php echo e($lastExec); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
        <?php endfor; ?>


        <tr>
          <td>Мэдээний хугацаанд гүйцэтгэсэн</td>
          <td>Бүгд</td>
          <td>Өмнөх тайлангийн бүгд</td>
          <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $previousReportExecution = \App\Http\Controllers\ExecutionContoller::previousReportExecutionByComId($company->id);
            ?>
            <td><?php echo e($previousReportExecution); ?></td>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <tr>
          <td>Мэдээний хугацаанд гүйцэтгэсэн</td>
          <td>Бүгд</td>
          <td>Тайлант үеийн</td>
          <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $lastExec = \App\Http\Controllers\ExecutionContoller::getLastExecByComId($company->id);
            ?>
            <td><?php echo e($lastExec); ?></td>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
      </tbody>
    </table>
    </div>
    
    <?php if($j==3): ?>
      <div class="clearfix" id="clear"></div>
      <div class="col-md-3">
        <table  border="1" class="allTable">
          <thead>
            <tr>
              <th colspan="<?php echo e($hesegs->count()+3); ?>">МЭДЭЭНИЙ ТОВЧОО</th>
            </tr>
            <tr>
              <th colspan="2"></th>
              <?php $__currentLoopData = $hesegs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heseg1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th><?php echo e($heseg1->name); ?></th>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <th>Бүгд</th>
            </tr>
            <tr>
              <th colspan="2">Хариуцах ПК-ийн байршил</th>
              <?php $__currentLoopData = $hesegs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heseg1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th><?php echo e($heseg1->ajliinHeseg); ?></th>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <th></th>
            </tr>
            <tr>
              <th colspan="2">Батлагдсан тоо хэмжээ /м.куб/</th>
              <?php $__currentLoopData = $hesegs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heseg1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $plan = \App\Http\Controllers\planController::getPlanSections($heseg1->id);
                ?>
                <?php if($plan == null || $plan == ""): ?>
                  <th>0</th>
                <?php else: ?>
                  <th><?php echo e(round($plan, 2)); ?></th>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <th></th>
            </tr>
            <tr>
              <th colspan="2">2019 оны гүйцэтгэл /хувь/</th>
              <?php $__currentLoopData = $hesegs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heseg1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $per2019 = \App\Http\Controllers\planController::getExecPercent2019($heseg1->id);
                $plan = \App\Http\Controllers\planController::getPlanSections($heseg1->id);
              ?>
                <?php if($plan == null || $plan == ""): ?>
                  <th>0</th>
                <?php else: ?>
                  <th><?php echo e(round($per2019*100/$plan, 2)); ?></th>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <th></th>
            </tr>
            <tr>
              <th colspan="2">2020 онд гүйцэтгэх тоо хэмжээ /м.куб/</th>
              <?php $__currentLoopData = $hesegs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heseg1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $per2019 = \App\Http\Controllers\planController::getExecPercent2019($heseg1->id);
                  $plan = \App\Http\Controllers\planController::getPlanSections($heseg1->id);
                ?>
                <th><?php echo e($plan-$per2019); ?></th>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php
              $works = \App\Http\Controllers\WorkController::getWorksAll($company->id);
            ?>
            <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="<?php echo e($work->work_type_id); ?>" id="prev<?php echo e($work->id); ?>">
                <td><?php echo e($work->name); ?></td>
                <td>Өмнөх тайл бүгд</td>
                <?php
                  $heseg1s = \App\Http\Controllers\HesegController::getHeseg();
                ?>
                <?php $__currentLoopData = $heseg1s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heseg1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                    $allExec = \App\Http\Controllers\ExecutionContoller::getAllExecutionByHeseg($heseg1->id, $work->id);
                    $lastExec = \App\Http\Controllers\ExecutionContoller::getLastExecutionByHeseg($heseg1->id, $work->id);
                  ?>
                  <td><?php echo e($allExec-$lastExec); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td></td>
              </tr>
              <tr class="<?php echo e($work->work_type_id); ?>" id="report<?php echo e($work->id); ?>">
                <td><?php echo e($work->name); ?></td>
                <td>Тайлант үеийн</td>
                <?php
                  $heseg1s = \App\Http\Controllers\HesegController::getHeseg();
                ?>
                <?php $__currentLoopData = $heseg1s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heseg1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                    $lastExec = \App\Http\Controllers\ExecutionContoller::getLastExecutionByHeseg($heseg1->id, $work->id);
                  ?>
                  <td><?php echo e($lastExec); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>

  </div>
  
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zam\resources\views/report/printReport.blade.php ENDPATH**/ ?>
<script>
$(document).ready(function () {
            $('#jqChart').jqChart({
                title: { text: 'Гүйцэтгэлт /хоногоор/, /м.куб/' },
                animation: { duration: 2 },
                axes: [
                    {
                        type: 'dateTime',
                        location: 'bottom',
                        interval: 1,
                        intervalType: 'days' // 'years' |  'months' | 'weeks' | 'days' | 'minutes' | 'seconds' | 'millisecond'
                    }
                ],
                series: [

                    {
                        type: 'line',
                        title: 'Хөрс хуулалт',
                        data: [
                          <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php
                            $date = explode("-",$data->ognoo);
                          ?>
                          <?php if($data->gHursHuulalt != null): ?>
                          [new Date(<?php echo e($date[0]); ?>, <?php echo e($date[1]-1); ?>, <?php echo e($date[2]); ?>), <?php echo e($data->gHursHuulalt); ?>],
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ]
                    },
                    {
                        type: 'line',
                        title: 'Далан',
                        data: [
                          <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                          $date = explode("-",$data->ognoo);
                        ?>
                        <?php if($data->gDalan != null): ?>
                        [new Date(<?php echo e($date[0]); ?>, <?php echo e($date[1]-1); ?>, <?php echo e($date[2]); ?>), <?php echo e($data->gDalan); ?>],
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      ]
                    },
                    {
                        type: 'line',
                        title: 'Ухмал',
                        data: [
                          <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                          $date = explode("-",$data->ognoo);
                        ?>
                        <?php if($data->gUhmal != null): ?>
                        [new Date(<?php echo e($date[0]); ?>, <?php echo e($date[1]-1); ?>, <?php echo e($date[2]); ?>), <?php echo e($data->gUhmal); ?>],
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      ]
                    },
                    {
                        type: 'line',
                        title: 'Суурийн үе',
                        data: [
                          <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                          $date = explode("-",$data->ognoo);
                        ?>
                        <?php if($data->gSuuriinUy != null): ?>
                        [new Date(<?php echo e($date[0]); ?>, <?php echo e($date[1]-1); ?>, <?php echo e($date[2]); ?>), <?php echo e($data->gSuuriinUy); ?>],

                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      ]
                    },
                    {
                        type: 'line',
                        title: 'Шуудуу',
                        data: [
                          <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                          $date = explode("-",$data->ognoo);
                        ?>
                        <?php if($data->gShuuduu != null): ?>
                        [new Date(<?php echo e($date[0]); ?>, <?php echo e($date[1]-1); ?>, <?php echo e($date[2]); ?>), <?php echo e($data->gShuuduu); ?>],

                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      ]
                    },
                    {
                        type: 'line',
                        title: 'Ухмалын хамгаалалт',
                        data: [
                          <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                          $date = explode("-",$data->ognoo);
                        ?>
                        <?php if($data->gUhmaliinHamgaalalt != null): ?>
                        [new Date(<?php echo e($date[0]); ?>, <?php echo e($date[1]-1); ?>, <?php echo e($date[2]); ?>), <?php echo e($data->gUhmaliinHamgaalalt); ?>],
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      ]
                    },
                    {
                        type: 'line',
                        title: 'Уулын шуудуу',
                        data: [
                          <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                          $date = explode("-",$data->ognoo);
                        ?>
                        <?php if($data->gUuliinShuuduu != null): ?>
                        [new Date(<?php echo e($date[0]); ?>, <?php echo e($date[1]-1); ?>, <?php echo e($date[2]); ?>), <?php echo e($data->gUuliinShuuduu); ?>],
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      ]
                    }
                ]
            });
        });
</script>
<?php /**PATH C:\xampp\htdocs\zam\resources\views/chart/chartByDate.blade.php ENDPATH**/ ?>
<script>
$(document).ready(function () {
    $('#jqChart').jqChart({
        title: { text: 'Гүйцэтгэлт /хоногоор/, /м.куб/' },
        animation: { duration: 2 },
        axes: [
            {
                type: 'dateTime',
                location: 'bottom',
                interval: 1,
                intervalType: 'days' // 'years' |  'months' | 'weeks' | 'days' | 'minutes' | 'seconds' | 'millisecond'
            }
        ],
        series: [
          <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            {
                type: 'line',
                title: '<?php echo e($data->nameExec); ?>',
                data: [

                  <?php
                    $works = App\Http\Controllers\GuitsetgelController::getWorkExecution($data->companyID, $data->work_id);
                    $tot = 0;
                  ?>
                    <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php
                        $date = explode("-",$work->date);
                        $tot += $work->execution;
                        if($work->execution != null)
                          echo "[new Date(($date[0]), $date[1]-1, $date[2]), $tot],";


                      ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ]
            },
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        ]
    });
});
</script>
<?php /**PATH C:\xampp\htdocs\zam\resources\views/chart/chartByDate.blade.php ENDPATH**/ ?>
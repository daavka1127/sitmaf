<?php $__env->startSection('content'); ?>
<?php include 'test.html'; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zam\resources\views/report/viewHtml.blade.php ENDPATH**/ ?>